/*
 * ISR.c
 *
 *  Created on: May 4, 2023
 *      Author: ea871
 */
#include "derivative.h"
#include "buffer_circular.h"
#include "ISR.h"

#define TAM_MAX 13
static uint8_t flag;
static BufferCirc_type bufferE;				//buffer de entrada
static BufferCirc_type bufferS;	//buffer de saida Terminal 

void UART0_IRQHandler()
{
#if UART_MODE == INTERRUPT_MODE
void UART0_IRQHandler (void)
{
	uint8_t c;

	if (UART0_S1&UART_S1_RDRF_MASK)
	{
		c = UART0_D;
		//A logica do codigo do Manual nao esta correto. As flags em 1 indicam a disponibilidade.
//		if (!(UART0_S1&UART_S1_TDRE_MASK) && !(UART0_S1&UART_S1_TC_MASK))
		if ((UART0_S1&UART_S1_TDRE_MASK) && (UART0_S1&UART_S1_TC_MASK))
		{
			UART0_D = c;
		}
	}
}
#endif
	/*char item;
	if (UART0_S1 & UART0_S1_RDRF_MASK) {
		item= UART0_D;
		UART0_D = item;
		if (item == '\r') {
			BC_push (&bufferE, '\0');
			while (!(UART0_S1 & UART_S1_TDRE_MASK));
			UART0_D = '\n';
		} 
		else {
			BC_push (&bufferE, item);
		}
	} else if (UART0_S1 & UART0_S1_TDRE_MASK) {
		if (BC_isEmpty(&bufferS))
			UART0_C2 &= ~UART0_C2_TIE_MASK;
		else {
			BC_pop (&bufferS, &item);
			UART0_D = item;
		}
	}*/
}


void ISR_inicializaBC () {
	/*!
	 * Inicializa um buffer circular de entrada
	 */
	BC_init (&bufferE, TAM_MAX);

	/*!
	 * Inicializa o buffer circular de saida
	 */
	BC_init(&bufferS, TAM_MAX);
}

void ISR_EnviaString (char *string) {
	uint8_t i;
	
	while (BC_push( &bufferS, string[0])==-1);
	UART0_C2 |= UART0_C2_TIE_MASK;
	i=1;
	while (string[i] != '\0') {
		while (BC_push( &bufferS, string[i])==-1);
		i++;
	}
}

void ISR_extraiString (char *string) {
	//Entrada de uma nova string
	uint8_t i=0;
	BC_pop (&bufferE, &string[i]);
	while (string[i] != '\0') {
		BC_pop (&bufferE, &string[++i]);				
	}
}
