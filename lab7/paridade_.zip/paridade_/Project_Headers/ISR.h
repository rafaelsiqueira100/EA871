/*
 * ISR.h
 */
#ifndef ISR_H_
#define ISR_H_
#define POLLING_MODE 1
#define INTERRUPT_MODE 2
//#define UART_MODE POLLING_MODE 
//#define UART_MODE INTERRUPT_MODE

typedef enum estado_tag {
	MENSAGEM,
	EXPRESSAO,
	TOKENS,
	COMPUTO,
	RESULTADO,
	ERRO,
} tipo_estado;

#endif /* ISR_H_ */
void ISR_inicializaBC();
void ISR_EnviaString (char *string);
void ISR_extraiString (char *string);

