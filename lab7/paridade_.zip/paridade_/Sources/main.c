/*
 * main implementation: use this 'C' sample to create your own application
 *
 */
/**
 * @file main.c
 * @brief Este projeto demonstra o uso de um buffer circular para compatibilizar
 * a velocidade de dois dispositivos. Ao digitar uma das seguintes palavras em maiusculas 		
 * VERDE, VINHO, VIOLETA, VERMELHO, VIRIDIANO, s�o "ecoadas" a palavra digitada 10x no Terminal 
 * @author Beatriz Moura e Rafael Andre
 * @date 04/05/2023
 *
 */
#include "stdlib.h"
#include "string.h"
#include "UART.h"
#include "ISR.h"
#include "SIM.h"
#include "buffer_circular.h"
#include "derivative.h" /* include peripheral declarations */
uint8_t ExtraiString2Tokens (char *str,uint8_t *i, char **tokens){
	char delim= ' '; //Delimitador
	
	//Extracao do primeiro token
	tokens[0]=strtok(str, delim); //Op
	
	if(*tokens[0]!='I' && *tokens[0]!='i' && *tokens[0]!='p' && *tokens[0]!='P'){
		return 3; //Operacao invalida
	}
	*i+=1;
	tokens[1]=strtok(NULL, delim); //Valor
	*i+=1;
	while(strtok(NULL,delim)!=NULL){
		*i+=1; 
	}
	if(*i != 2){
			return 1; //Quantidade incorreta de tokens
		}
	return 0;
}
int main(void)
{		
	uint8_t i; 
	char tokens[2];
	char str;
	SIM_setaFLLPLL (0);              //seta FLL
	/*
	* Configurar sinais de relogio e pinos
	*/
	UART0_config_basica(0b1);
	/*
	* Configura o modulo UART0
	*/
	//MCGFLLCLK em 20,971520MHz
	UART0_config_especifica(20971520, 38400, 0x0B, 2);
	
	//Habilitar a interrupcao do canal Rx 
	UART0_habilitaInterruptRxTerminal();
	//enable_irq(12); set_irq_priority(12, 3);
	UART0_habilitaNVICIRQ12(0b11);
	
	ISR_inicializaBC();
	ISR_extraiString(&str);
	uint8_t sign = ExtraiString2Tokens (&str, &i, &tokens);
	for(;;) {	   

	}
	
	return 0;
}
