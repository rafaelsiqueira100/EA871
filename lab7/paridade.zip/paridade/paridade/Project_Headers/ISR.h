/*
 * ISR.h
 *
 *  Created on: May 4, 2023
 *      Author: ea871
 */

#ifndef ISR_H_
#define ISR_H_
#define POLLING_MODE 1
#define INTERRUPT_MODE 2
#define UART_MODE POLLING_MODE //INTERRUPT_MODE
//#define UART_MODE INTERRUPT_MODE

typedef enum estado_tag {
	MENSAGEM,
	EXPRESSAO,
	TOKENS,
	COMPUTO,
	RESULTADO,
	ERRO,
} tipo_estado;

#endif /* ISR_H_ */
