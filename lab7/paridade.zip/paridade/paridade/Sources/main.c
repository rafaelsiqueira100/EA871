/*
 * main implementation: use this 'C' sample to create your own application
 *
 */
/**
 * @file main.c
 * @brief Este projeto demonstra o uso de um buffer circular para compatibilizar
 * a velocidade de dois dispositivos. Ao digitar uma das seguintes palavras em maiusculas 		
 * VERDE, VINHO, VIOLETA, VERMELHO, VIRIDIANO, s�o "ecoadas" a palavra digitada 10x no Terminal 
 * @author Beatriz Moura e Rafael Andre
 * @date 04/05/2023
 *
 */
#include "stdlib.h"
#include "string.h"
#include "MCG.h"
#include "UART.h"
#include "ISR.h"
#include "SIM.h"
#include "buffer_circular.h"
#include "derivative.h" /* include peripheral declarations */


int main(void)
{
	/*
	* Habilitar MCGFLLCLK 48MHz
	*/
	MCG_initFLL48MH();
		
	SIM_setaFLLPLL (0);              //seta FLL

	/*
	* Configurar sinais de relogio e pinos
	*/
	UART0_config_basica(0b1);
		
	/*
	* Configura o modulo UART0
	*/
	//MCGFLLCLK em 48MHz
	UART0_config_especifica(48000000, 38400, 0x0C);

	
	
	
	
	for(;;) {	   
#if UART_MODE == POLLING_MODE
		uint8_t c;
		
		while(!(UART0_S1&UART_S1_RDRF_MASK));
		c = UART0_D;
		while(!(UART0_S1&UART_S1_TDRE_MASK) && !(UART0_S1&UART_S1_TC_MASK));
		UART0_D = c;
#endif
	}
	
	return 0;
}
