var _u_a_r_t_8h =
[
    [ "UART0_config_basica", "_u_a_r_t_8h.html#a447aaf663f833e8d24f2e61cea3f5a00", null ],
    [ "UART0_config_especifica", "_u_a_r_t_8h.html#aa2d784b319dd596eabcc081a9ce631d9", null ],
    [ "UART0_desabilitaInterruptRxTerminal", "_u_a_r_t_8h.html#ac0c437994f69fece5fca83267f33b4d5", null ],
    [ "UART0_desabilitaInterruptTxTerminal", "_u_a_r_t_8h.html#a6c3c298b57aa879744eb6b0453c8fa1f", null ],
    [ "UART0_habilitaInterruptRxTerminal", "_u_a_r_t_8h.html#a2df785095fa4cd887f0221d1799a6f81", null ],
    [ "UART0_habilitaInterruptTxTerminal", "_u_a_r_t_8h.html#aa1d9aca29fa87756761d72d0fad37aa5", null ],
    [ "UART0_habilitaNVICIRQ12", "_u_a_r_t_8h.html#a9211c6f496c4779854b7ee713eecf2a5", null ],
    [ "UART0_SBR", "_u_a_r_t_8h.html#aed9574fc0eb715bc388bc18445d9b62d", null ]
];