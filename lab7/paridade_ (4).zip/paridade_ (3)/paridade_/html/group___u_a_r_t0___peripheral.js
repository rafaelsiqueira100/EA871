var group___u_a_r_t0___peripheral =
[
    [ "UART0 - Register accessor macros", "group___u_a_r_t0___register___accessor___macros.html", null ],
    [ "UART0 Register Masks", "group___u_a_r_t0___register___masks.html", null ],
    [ "UART0_MemMap", "struct_u_a_r_t0___mem_map.html", [
      [ "BDH", "struct_u_a_r_t0___mem_map.html#a411dcb9ed04cf79fe75d29e9636b435c", null ],
      [ "BDL", "struct_u_a_r_t0___mem_map.html#a0cfc5d11f450bc767b9e0f8cb15cbfd1", null ],
      [ "C1", "struct_u_a_r_t0___mem_map.html#ad2751b249e6fcca4924bbd0f431e96e1", null ],
      [ "C2", "struct_u_a_r_t0___mem_map.html#ab8c8c0d1c432b1580bc02235a62266fb", null ],
      [ "C3", "struct_u_a_r_t0___mem_map.html#ac603121476ec4ef860596f137bc85bdd", null ],
      [ "C4", "struct_u_a_r_t0___mem_map.html#ae1147f361a00a4029f045003d71df762", null ],
      [ "C5", "struct_u_a_r_t0___mem_map.html#a85d7203b42739b4a364e0f82fc17c391", null ],
      [ "D", "struct_u_a_r_t0___mem_map.html#a9ed4a4e4a34f425d3b625106eff08700", null ],
      [ "MA1", "struct_u_a_r_t0___mem_map.html#a84dcf3f91ccba87c62fdbf25264ee660", null ],
      [ "MA2", "struct_u_a_r_t0___mem_map.html#a13b6861472650bfda5bd6843fde687a4", null ],
      [ "S1", "struct_u_a_r_t0___mem_map.html#ac4cfda6527bfad520a55ddeb3d70d669", null ],
      [ "S2", "struct_u_a_r_t0___mem_map.html#ab34f7b8ed424a024a723effca847f5ec", null ]
    ] ],
    [ "UART0_BASE_PTR", "group___u_a_r_t0___peripheral.html#ga50a02c91ffbd11fa7b4f0c33fe585199", null ],
    [ "UART0_BASE_PTRS", "group___u_a_r_t0___peripheral.html#ga9416d89d2bc04eb37311da5910f1c701", null ],
    [ "UART0_MemMapPtr", "group___u_a_r_t0___peripheral.html#gae795171499e041fb9b8f6ad5b97f896b", null ]
];