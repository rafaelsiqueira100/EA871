var group___u_a_r_t___peripheral =
[
    [ "UART - Register accessor macros", "group___u_a_r_t___register___accessor___macros.html", null ],
    [ "UART Register Masks", "group___u_a_r_t___register___masks.html", null ],
    [ "UART_MemMap", "struct_u_a_r_t___mem_map.html", [
      [ "BDH", "struct_u_a_r_t___mem_map.html#a50621a015b23211a706aa74180fa4689", null ],
      [ "BDL", "struct_u_a_r_t___mem_map.html#ac846186ffd0e53fbac32cd57c6f9acc4", null ],
      [ "C1", "struct_u_a_r_t___mem_map.html#ac2300c7c40e63ca712d0ec5180332f4b", null ],
      [ "C2", "struct_u_a_r_t___mem_map.html#a3e49aeb27f3613fd01a17a3c76e785b7", null ],
      [ "C3", "struct_u_a_r_t___mem_map.html#a2e3cebfbfb9d96766397a8a102b8c29c", null ],
      [ "C4", "struct_u_a_r_t___mem_map.html#a6f18d698404d3f130cab66610aa526de", null ],
      [ "D", "struct_u_a_r_t___mem_map.html#a3568c1640bf7dc0e1214cddcea1e8f0c", null ],
      [ "S1", "struct_u_a_r_t___mem_map.html#a7eb8df4e43194dbd9f1d9bd4ab742cca", null ],
      [ "S2", "struct_u_a_r_t___mem_map.html#a6107c55f4dba727e1a4e70f76acd7b20", null ]
    ] ],
    [ "UART1_BASE_PTR", "group___u_a_r_t___peripheral.html#gafb5b1236c1cdf2d9a6464251b791030c", null ],
    [ "UART2_BASE_PTR", "group___u_a_r_t___peripheral.html#ga75ca2ea4e490b3c1c7aa55fc9c25cd37", null ],
    [ "UART_BASE_PTRS", "group___u_a_r_t___peripheral.html#ga7b34a38b9492a1e1007b2f66383aef17", null ],
    [ "UART_MemMapPtr", "group___u_a_r_t___peripheral.html#ga306cf44b593fadbb29a065f42e3f68f0", null ]
];