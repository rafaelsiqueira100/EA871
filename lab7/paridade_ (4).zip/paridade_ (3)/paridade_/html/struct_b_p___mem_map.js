var struct_b_p___mem_map =
[
    [ "CID0", "struct_b_p___mem_map.html#a533b8c0657ac258f340baaea96ecc00c", null ],
    [ "CID1", "struct_b_p___mem_map.html#aecbf01d7c8fd4689e6ede5b9c12b3d94", null ],
    [ "CID2", "struct_b_p___mem_map.html#a3900abf0b057f791c7fe66a79862f837", null ],
    [ "CID3", "struct_b_p___mem_map.html#a26076f956d1700acaeb0c9db60846606", null ],
    [ "COMP", "struct_b_p___mem_map.html#ac8c266a109ad2f29683dfb7873b71974", null ],
    [ "CTRL", "struct_b_p___mem_map.html#adc78a44bcbb6564277efefa8f07439ce", null ],
    [ "PID0", "struct_b_p___mem_map.html#acb1de7fb15f421c81ddfbf6feba0c4f2", null ],
    [ "PID1", "struct_b_p___mem_map.html#a2b27e33fff1d3730366050ede44cb7c3", null ],
    [ "PID2", "struct_b_p___mem_map.html#a76e6da948034b317948bbe7b794b02c6", null ],
    [ "PID3", "struct_b_p___mem_map.html#a556f1775a26cc79e8ab97c8452ce2c41", null ],
    [ "PID4", "struct_b_p___mem_map.html#a1e7c67c7222aedc5a3c16c5560748793", null ],
    [ "PID5", "struct_b_p___mem_map.html#abb77e60e581e55fe33af44ebf1030116", null ],
    [ "PID6", "struct_b_p___mem_map.html#a9f611c760b2dc672f72485a6751ae703", null ],
    [ "PID7", "struct_b_p___mem_map.html#a60dff3ca8ab0f81ef166fffd7fbc3356", null ]
];