var struct_o_s_c___mem_map =
[
    [ "CR", "struct_o_s_c___mem_map.html#adb3c443099915a22c9951ff23c8eaa16", null ]
];