var struct_d_w_t___mem_map =
[
    [ "COMP", "struct_d_w_t___mem_map.html#ae10b19c1d610d27a71a1dc34a84a0e60", null ],
    [ "CTRL", "struct_d_w_t___mem_map.html#ab3581abb33e428126e7ec339e66514e4", null ],
    [ "FUNCTION", "struct_d_w_t___mem_map.html#ad60c09cefe311e7809d9a57fad402f5c", null ],
    [ "MASK", "struct_d_w_t___mem_map.html#a34e5e25a9ec81fc61eca09c6d6adadfa", null ],
    [ "PCSR", "struct_d_w_t___mem_map.html#a58d461cd26674ff3bce87778c4b54164", null ]
];