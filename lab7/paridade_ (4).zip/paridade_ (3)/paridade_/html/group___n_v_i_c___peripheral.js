var group___n_v_i_c___peripheral =
[
    [ "NVIC - Register accessor macros", "group___n_v_i_c___register___accessor___macros.html", null ],
    [ "NVIC Register Masks", "group___n_v_i_c___register___masks.html", null ],
    [ "NVIC_MemMap", "struct_n_v_i_c___mem_map.html", [
      [ "ICER", "struct_n_v_i_c___mem_map.html#a0def6b0bebb3e2e35a180f31f74baef8", null ],
      [ "ICPR", "struct_n_v_i_c___mem_map.html#a47b16d0ffa924a50639a73c0494913b0", null ],
      [ "IP", "struct_n_v_i_c___mem_map.html#a4dae41a548b9558e16c2280c8695a6f8", null ],
      [ "ISER", "struct_n_v_i_c___mem_map.html#aaa8fb79136e7f528c4644ca658d637e8", null ],
      [ "ISPR", "struct_n_v_i_c___mem_map.html#a91ab049ba145735fc8d9319f3b0f0cb4", null ]
    ] ],
    [ "NVIC_BASE_PTR", "group___n_v_i_c___peripheral.html#ga28f0a055d0c218e16d1fc7b13ff0caa5", null ],
    [ "NVIC_BASE_PTRS", "group___n_v_i_c___peripheral.html#ga25b6ce0c871e09199e515cbb1716fe26", null ],
    [ "NVIC_MemMapPtr", "group___n_v_i_c___peripheral.html#ga685d87c766bb24fb3330aa8cc48fa0e7", null ]
];