var struct_d_m_a___mem_map =
[
    [ "DAR", "struct_d_m_a___mem_map.html#a22aca0a7ea6ca1da1a58f0fe6f32166f", null ],
    [ "DCR", "struct_d_m_a___mem_map.html#a844c0fef8183d262baec56c84a07c070", null ],
    [ "DSR", "struct_d_m_a___mem_map.html#a386ac5fd0aa8748b87f2de231c917b07", null ],
    [ "DSR_BCR", "struct_d_m_a___mem_map.html#ad1e76cea4d92082ca9ed0d760ce5cefe", null ],
    [ "SAR", "struct_d_m_a___mem_map.html#a800d089db050cc5c5376f4fd1b8607f4", null ]
];