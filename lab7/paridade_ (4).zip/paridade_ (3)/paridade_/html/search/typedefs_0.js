var searchData=
[
  ['adc_5fmemmapptr',['ADC_MemMapPtr',['../group___a_d_c___peripheral.html#ga1673c677bf7c0ca339c8563e06de75fa',1,'MKL25Z4.h']]]
];
