var searchData=
[
  ['espera',['espera',['../util_8h.html#a16cc82fb968dcc6281cd3efc9bc2a982',1,'espera(uint32_t valor):&#160;util.c'],['../util_8c.html#a16cc82fb968dcc6281cd3efc9bc2a982',1,'espera(uint32_t valor):&#160;util.c']]],
  ['espera_5f5us',['espera_5us',['../util_8h.html#aeeb1d363914f33616415732d3b842cee',1,'espera_5us(uint32_t multiplos):&#160;util.c'],['../util_8c.html#aeeb1d363914f33616415732d3b842cee',1,'espera_5us(uint32_t multiplos):&#160;util.c']]]
];
