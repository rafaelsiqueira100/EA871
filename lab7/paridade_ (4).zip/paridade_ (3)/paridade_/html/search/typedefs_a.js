var searchData=
[
  ['osc_5fmemmapptr',['OSC_MemMapPtr',['../group___o_s_c___peripheral.html#gaaa685163f549fdf24c28ec9b400310b5',1,'MKL25Z4.h']]]
];
