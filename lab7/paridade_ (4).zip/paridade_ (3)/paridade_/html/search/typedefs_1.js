var searchData=
[
  ['bp_5fmemmapptr',['BP_MemMapPtr',['../group___b_p___peripheral.html#gaa250950ffe336f8c6e5895e3a1e4ca86',1,'MKL25Z4.h']]]
];
