var searchData=
[
  ['gencs',['GENCS',['../struct_t_s_i___mem_map.html#a14380d508e161af3b794962e7c3f8abb',1,'TSI_MemMap']]],
  ['gpchr',['GPCHR',['../struct_p_o_r_t___mem_map.html#a84f8893cbefd6a3eff18b455f9069b29',1,'PORT_MemMap']]],
  ['gpclr',['GPCLR',['../struct_p_o_r_t___mem_map.html#a837c289643f8cec958b1f01c086b558a',1,'PORT_MemMap']]]
];
