var searchData=
[
  ['a1',['A1',['../struct_i2_c___mem_map.html#aefc602e5555ff9807f66ba8d67c214c0',1,'I2C_MemMap']]],
  ['a2',['A2',['../struct_i2_c___mem_map.html#ad4e4dbcd884a2b52af7dbef17817f12e',1,'I2C_MemMap']]],
  ['actlr',['ACTLR',['../struct_s_c_b___mem_map.html#a474a33074611146734690e48ed41282e',1,'SCB_MemMap']]],
  ['adc0_5fbase_5fptr',['ADC0_BASE_PTR',['../group___a_d_c___peripheral.html#ga6cec2f227a3a37a9fccaa830740f1f5e',1,'MKL25Z4.h']]],
  ['adc_5fbase_5fptrs',['ADC_BASE_PTRS',['../group___a_d_c___peripheral.html#gaaa8175a3a2f4efaceeed5bd26c0b2d3f',1,'MKL25Z4.h']]],
  ['adc_5fmemmap',['ADC_MemMap',['../struct_a_d_c___mem_map.html',1,'']]],
  ['adc_5fmemmapptr',['ADC_MemMapPtr',['../group___a_d_c___peripheral.html#ga1673c677bf7c0ca339c8563e06de75fa',1,'MKL25Z4.h']]],
  ['adc',['ADC',['../group___a_d_c___peripheral.html',1,'']]],
  ['adc_20_2d_20register_20accessor_20macros',['ADC - Register accessor macros',['../group___a_d_c___register___accessor___macros.html',1,'']]],
  ['adc_20register_20masks',['ADC Register Masks',['../group___a_d_c___register___masks.html',1,'']]],
  ['addinfo',['ADDINFO',['../struct_u_s_b___mem_map.html#aa87a73875ff45abb9b84992687f48000',1,'USB_MemMap']]],
  ['addr',['ADDR',['../struct_u_s_b___mem_map.html#a6b1fac9acdf7f6c7e0471af3886c6a8e',1,'USB_MemMap']]],
  ['aircr',['AIRCR',['../struct_s_c_b___mem_map.html#a3f874ca1c6e17ae4beadac22e8ec17ec',1,'SCB_MemMap']]],
  ['atcvh',['ATCVH',['../struct_m_c_g___mem_map.html#a74fee35955b4ec57aa8058bd57a926a8',1,'MCG_MemMap']]],
  ['atcvl',['ATCVL',['../struct_m_c_g___mem_map.html#a913b6fd7776c0377e299fdf0eeb166af',1,'MCG_MemMap']]],
  ['authstat',['AUTHSTAT',['../struct_m_t_b___mem_map.html#a5bc0007724226eb21df485ee381283e1',1,'MTB_MemMap']]]
];
