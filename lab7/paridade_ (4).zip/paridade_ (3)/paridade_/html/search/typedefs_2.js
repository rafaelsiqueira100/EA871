var searchData=
[
  ['cmp_5fmemmapptr',['CMP_MemMapPtr',['../group___c_m_p___peripheral.html#ga6f5d370df3839e41b771c2d0b89cbb83',1,'MKL25Z4.h']]],
  ['coredebug_5fmemmapptr',['CoreDebug_MemMapPtr',['../group___core_debug___peripheral.html#gaa548220bc91b12bd49065fe752579fcd',1,'MKL25Z4.h']]]
];
