var struct_s_i_m___mem_map =
[
    [ "CLKDIV1", "struct_s_i_m___mem_map.html#afa315c39ebd4ef380b7f8d67a88d4f82", null ],
    [ "COPC", "struct_s_i_m___mem_map.html#adb743819184b25914372606a57d6e416", null ],
    [ "FCFG1", "struct_s_i_m___mem_map.html#a2b78edd16e6d046eb3399182216bf816", null ],
    [ "FCFG2", "struct_s_i_m___mem_map.html#afd105923b2815e01119a5bc195ceebd6", null ],
    [ "SCGC4", "struct_s_i_m___mem_map.html#a96c123ab70356a131990c9ae3812834e", null ],
    [ "SCGC5", "struct_s_i_m___mem_map.html#ae9d560d3862eb171c739acaf92daa8aa", null ],
    [ "SCGC6", "struct_s_i_m___mem_map.html#ad40dd833ac37056f5341b692039a5f10", null ],
    [ "SCGC7", "struct_s_i_m___mem_map.html#aa35362a8c756eedb82b8cf00f98c43da", null ],
    [ "SDID", "struct_s_i_m___mem_map.html#a536b8d3e185149c51e88387350e20fb3", null ],
    [ "SOPT1", "struct_s_i_m___mem_map.html#a1152a6ef88c78e762df97badf10b5050", null ],
    [ "SOPT1CFG", "struct_s_i_m___mem_map.html#a9b6ea6819e80eeaa90754b6e91fcc808", null ],
    [ "SOPT2", "struct_s_i_m___mem_map.html#ae4c4bf827aeca9c2de082cdfafdea3d1", null ],
    [ "SOPT4", "struct_s_i_m___mem_map.html#adf28cda65cea7072379ec6064d0d93cc", null ],
    [ "SOPT5", "struct_s_i_m___mem_map.html#a19e2ddf391b1d9c03240be8267fdf781", null ],
    [ "SOPT7", "struct_s_i_m___mem_map.html#a04a22056fd7d08179705d29cda1b9e2a", null ],
    [ "SRVCOP", "struct_s_i_m___mem_map.html#aa6f9efca2d70bfed14630de650d77ba8", null ],
    [ "UIDL", "struct_s_i_m___mem_map.html#ac23a694afa8d84e55fc43ff0c0ec1b29", null ],
    [ "UIDMH", "struct_s_i_m___mem_map.html#af4fb6d5bc3fa71f9c905570d87a2e93f", null ],
    [ "UIDML", "struct_s_i_m___mem_map.html#a51e871d8ac13db8b605b6ec1b3292be4", null ]
];