var group___f_t_f_a___peripheral =
[
    [ "FTFA - Register accessor macros", "group___f_t_f_a___register___accessor___macros.html", null ],
    [ "FTFA Register Masks", "group___f_t_f_a___register___masks.html", null ],
    [ "FTFA_MemMap", "struct_f_t_f_a___mem_map.html", [
      [ "FCCOB0", "struct_f_t_f_a___mem_map.html#a00d6a6b8dd8b276346a2ed32e74d1e5a", null ],
      [ "FCCOB1", "struct_f_t_f_a___mem_map.html#a735b6bacdf0355f01b021572da2dc49c", null ],
      [ "FCCOB2", "struct_f_t_f_a___mem_map.html#a84bdc42ccb0012ffd76bc7878acb10e4", null ],
      [ "FCCOB3", "struct_f_t_f_a___mem_map.html#a2a9a7e1603f232e71dfc40c418b6518e", null ],
      [ "FCCOB4", "struct_f_t_f_a___mem_map.html#acfc0ac633b156ae48b3e3fdeaafde51b", null ],
      [ "FCCOB5", "struct_f_t_f_a___mem_map.html#ab6f832a0a58ddeb422d97dc9aa7b1400", null ],
      [ "FCCOB6", "struct_f_t_f_a___mem_map.html#adabdf0cf22dde1f882cbf48bcc25812e", null ],
      [ "FCCOB7", "struct_f_t_f_a___mem_map.html#ae75356f3f7ab83b1e970d6c0e4ec4001", null ],
      [ "FCCOB8", "struct_f_t_f_a___mem_map.html#a4827886fc87b827ebb288972ff05f5c3", null ],
      [ "FCCOB9", "struct_f_t_f_a___mem_map.html#ad58eb2c520219ec46caa68d6556dc479", null ],
      [ "FCCOBA", "struct_f_t_f_a___mem_map.html#ab167db24e2f5b86e4498c713331b41fc", null ],
      [ "FCCOBB", "struct_f_t_f_a___mem_map.html#a4492c1b3ac2ecf8e5ce1d046d2a5e149", null ],
      [ "FCNFG", "struct_f_t_f_a___mem_map.html#a8b566226492c86d3c48607e0d72f61db", null ],
      [ "FOPT", "struct_f_t_f_a___mem_map.html#add71f9fca54238033c0b928c740e8398", null ],
      [ "FPROT0", "struct_f_t_f_a___mem_map.html#aba5bfab2704e58af5ecacdb6b7faccbc", null ],
      [ "FPROT1", "struct_f_t_f_a___mem_map.html#a74c0cb8e137d3f4df7283f4b15203845", null ],
      [ "FPROT2", "struct_f_t_f_a___mem_map.html#a86f1c8547579b9a1b381c2f7fdaf03ef", null ],
      [ "FPROT3", "struct_f_t_f_a___mem_map.html#ad373eeb57136eb15831fa521d94d7858", null ],
      [ "FSEC", "struct_f_t_f_a___mem_map.html#a9595f5c1181b22cc6411876706f38409", null ],
      [ "FSTAT", "struct_f_t_f_a___mem_map.html#ad0320d81996a5bd9b58e1d4421afc8c1", null ]
    ] ],
    [ "FTFA_BASE_PTR", "group___f_t_f_a___peripheral.html#ga13ad52f12d5b04e5e01f69ab18ed9216", null ],
    [ "FTFA_BASE_PTRS", "group___f_t_f_a___peripheral.html#ga3f06770a713a2c02c4eec6b98daefd7e", null ],
    [ "FTFA_MemMapPtr", "group___f_t_f_a___peripheral.html#ga49d048bbeb55a090a5ecfe86ff767884", null ]
];