var group___s_p_i___peripheral =
[
    [ "SPI - Register accessor macros", "group___s_p_i___register___accessor___macros.html", null ],
    [ "SPI Register Masks", "group___s_p_i___register___masks.html", null ],
    [ "SPI_MemMap", "struct_s_p_i___mem_map.html", [
      [ "BR", "struct_s_p_i___mem_map.html#ad2c201cf5aa72904503df243610507b8", null ],
      [ "C1", "struct_s_p_i___mem_map.html#ab9f017bddfa72e299d9c0ab7ab400c1b", null ],
      [ "C2", "struct_s_p_i___mem_map.html#aae7ca381054324cf98aac30ce607046a", null ],
      [ "D", "struct_s_p_i___mem_map.html#aa940ca36df1b702c6c03557f442cde16", null ],
      [ "M", "struct_s_p_i___mem_map.html#acd26c314a794ed500a27a4b6bc51eec9", null ],
      [ "S", "struct_s_p_i___mem_map.html#ad905fa29c8b2f0ca5b93222e7961542b", null ]
    ] ],
    [ "SPI0_BASE_PTR", "group___s_p_i___peripheral.html#ga851f64a97b5919c1f99a34db5918b3b4", null ],
    [ "SPI1_BASE_PTR", "group___s_p_i___peripheral.html#gae28fd789e0602a32076c1c13ca39f5af", null ],
    [ "SPI_BASE_PTRS", "group___s_p_i___peripheral.html#ga3a16fecfe27c2052ab60e014be3f66f6", null ],
    [ "SPI_MemMapPtr", "group___s_p_i___peripheral.html#ga7e4e9921e4d56bdbb10a04e77743ff5e", null ]
];