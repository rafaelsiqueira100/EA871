var group___p_m_c___peripheral =
[
    [ "PMC - Register accessor macros", "group___p_m_c___register___accessor___macros.html", null ],
    [ "PMC Register Masks", "group___p_m_c___register___masks.html", null ],
    [ "PMC_MemMap", "struct_p_m_c___mem_map.html", [
      [ "LVDSC1", "struct_p_m_c___mem_map.html#aeed619ce4a5bf17bff6201b02deebb54", null ],
      [ "LVDSC2", "struct_p_m_c___mem_map.html#a934db8b39dae8b99a9a9165df50145f5", null ],
      [ "REGSC", "struct_p_m_c___mem_map.html#aa14a55a46cc237589d6c01ebf7676c2a", null ]
    ] ],
    [ "PMC_BASE_PTR", "group___p_m_c___peripheral.html#gaf32df9f1096263f10a5e8978a338b2ac", null ],
    [ "PMC_BASE_PTRS", "group___p_m_c___peripheral.html#ga4bcd62643d597f7230f9c1e3d03caaa7", null ],
    [ "PMC_MemMapPtr", "group___p_m_c___peripheral.html#ga0e73f22a2fa26cbb012851719e34812e", null ]
];