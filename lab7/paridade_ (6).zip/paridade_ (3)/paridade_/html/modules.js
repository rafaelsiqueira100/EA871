var modules =
[
    [ "Interrupt vector numbers", "group___interrupt__vector__numbers.html", "group___interrupt__vector__numbers" ],
    [ "Peripheral type defines", "group___peripheral__defines.html", "group___peripheral__defines" ],
    [ "Backward Compatibility", "group___backward___compatibility___symbols.html", null ]
];