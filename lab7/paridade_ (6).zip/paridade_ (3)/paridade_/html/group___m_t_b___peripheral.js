var group___m_t_b___peripheral =
[
    [ "MTB - Register accessor macros", "group___m_t_b___register___accessor___macros.html", null ],
    [ "MTB Register Masks", "group___m_t_b___register___masks.html", null ],
    [ "MTB_MemMap", "struct_m_t_b___mem_map.html", [
      [ "AUTHSTAT", "struct_m_t_b___mem_map.html#a5bc0007724226eb21df485ee381283e1", null ],
      [ "BASE", "struct_m_t_b___mem_map.html#a11667e8893e740c2275248dafcc874ed", null ],
      [ "COMPID", "struct_m_t_b___mem_map.html#aad4a8dcad1e9b3d04375b85c6c37f09f", null ],
      [ "DEVICEARCH", "struct_m_t_b___mem_map.html#a64a9fe1c83fa72b2b38696ed80856b73", null ],
      [ "DEVICECFG", "struct_m_t_b___mem_map.html#a85b25744edf0f8a61d1d40bdf636e87e", null ],
      [ "DEVICETYPID", "struct_m_t_b___mem_map.html#ae15d7775b4603c2f81ab69dcd560c523", null ],
      [ "FLOW", "struct_m_t_b___mem_map.html#a69ea771a865eb621e80af63894c65982", null ],
      [ "LOCKACCESS", "struct_m_t_b___mem_map.html#a6fea4948a50a4c0283e2fe15468ddb41", null ],
      [ "LOCKSTAT", "struct_m_t_b___mem_map.html#aac267fb66879aa477f7e0185507d688b", null ],
      [ "MASTER", "struct_m_t_b___mem_map.html#a4398e867901c87b7b9d86f7a4730d1c2", null ],
      [ "MODECTRL", "struct_m_t_b___mem_map.html#afb3fb2741fa86e77bf0e514f4d4dc96e", null ],
      [ "PERIPHID", "struct_m_t_b___mem_map.html#a1e121406a44ce4c5261292e960a86e29", null ],
      [ "POSITION", "struct_m_t_b___mem_map.html#af02973e301b85c6ea0c6ba7520b59173", null ],
      [ "TAGCLEAR", "struct_m_t_b___mem_map.html#a341492ac466b6c26b188093417006f72", null ],
      [ "TAGSET", "struct_m_t_b___mem_map.html#a5709bb3455f82d56406ad14e3a8c182e", null ]
    ] ],
    [ "MTB_BASE_PTR", "group___m_t_b___peripheral.html#gadf7f362dfa67354951e6a23ddf08cd73", null ],
    [ "MTB_BASE_PTRS", "group___m_t_b___peripheral.html#ga45b3138a9794fd8f2c7613b48646e44f", null ],
    [ "MTB_MemMapPtr", "group___m_t_b___peripheral.html#ga2d3d13148d5c08e92b1ad2eeb14342da", null ]
];