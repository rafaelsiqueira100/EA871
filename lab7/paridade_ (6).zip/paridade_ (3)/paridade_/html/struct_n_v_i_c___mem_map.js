var struct_n_v_i_c___mem_map =
[
    [ "ICER", "struct_n_v_i_c___mem_map.html#a0def6b0bebb3e2e35a180f31f74baef8", null ],
    [ "ICPR", "struct_n_v_i_c___mem_map.html#a47b16d0ffa924a50639a73c0494913b0", null ],
    [ "IP", "struct_n_v_i_c___mem_map.html#a4dae41a548b9558e16c2280c8695a6f8", null ],
    [ "ISER", "struct_n_v_i_c___mem_map.html#aaa8fb79136e7f528c4644ca658d637e8", null ],
    [ "ISPR", "struct_n_v_i_c___mem_map.html#a91ab049ba145735fc8d9319f3b0f0cb4", null ]
];