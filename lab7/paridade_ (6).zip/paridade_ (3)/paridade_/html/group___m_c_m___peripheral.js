var group___m_c_m___peripheral =
[
    [ "MCM - Register accessor macros", "group___m_c_m___register___accessor___macros.html", null ],
    [ "MCM Register Masks", "group___m_c_m___register___masks.html", null ],
    [ "MCM_MemMap", "struct_m_c_m___mem_map.html", [
      [ "CPO", "struct_m_c_m___mem_map.html#a887b6813ace7322a6dd2af1f71d7e6c6", null ],
      [ "PLACR", "struct_m_c_m___mem_map.html#a520575ffc4561724479404679213900b", null ],
      [ "PLAMC", "struct_m_c_m___mem_map.html#a7d749b910777a6b67ea94f2379c628ee", null ],
      [ "PLASC", "struct_m_c_m___mem_map.html#ad68f64d82524bb0b181a837967b8e248", null ]
    ] ],
    [ "MCM_BASE_PTR", "group___m_c_m___peripheral.html#gad41e931f176c230831e3dbad45117841", null ],
    [ "MCM_BASE_PTRS", "group___m_c_m___peripheral.html#gae2d5e838ce7d2d4108738c05bf224272", null ],
    [ "MCM_MemMapPtr", "group___m_c_m___peripheral.html#ga72e8bbe428d9410917903164d3a5f675", null ]
];