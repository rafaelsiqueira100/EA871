var group___d_w_t___peripheral =
[
    [ "DWT - Register accessor macros", "group___d_w_t___register___accessor___macros.html", null ],
    [ "DWT Register Masks", "group___d_w_t___register___masks.html", null ],
    [ "DWT_MemMap", "struct_d_w_t___mem_map.html", [
      [ "COMP", "struct_d_w_t___mem_map.html#ae10b19c1d610d27a71a1dc34a84a0e60", null ],
      [ "CTRL", "struct_d_w_t___mem_map.html#ab3581abb33e428126e7ec339e66514e4", null ],
      [ "FUNCTION", "struct_d_w_t___mem_map.html#ad60c09cefe311e7809d9a57fad402f5c", null ],
      [ "MASK", "struct_d_w_t___mem_map.html#a34e5e25a9ec81fc61eca09c6d6adadfa", null ],
      [ "PCSR", "struct_d_w_t___mem_map.html#a58d461cd26674ff3bce87778c4b54164", null ]
    ] ],
    [ "DWT_BASE_PTR", "group___d_w_t___peripheral.html#ga3b46dfb2ea7946c6938028d879c82cb1", null ],
    [ "DWT_BASE_PTRS", "group___d_w_t___peripheral.html#ga606d55285f2df3c4bb43272ec842b475", null ],
    [ "DWT_MemMapPtr", "group___d_w_t___peripheral.html#ga8a09a1b28d871c18ae8c69f67af6d573", null ]
];