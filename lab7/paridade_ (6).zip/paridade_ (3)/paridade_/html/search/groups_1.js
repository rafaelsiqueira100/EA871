var searchData=
[
  ['backward_20compatibility',['Backward Compatibility',['../group___backward___compatibility___symbols.html',1,'']]],
  ['bp',['BP',['../group___b_p___peripheral.html',1,'']]],
  ['bp_20_2d_20register_20accessor_20macros',['BP - Register accessor macros',['../group___b_p___register___accessor___macros.html',1,'']]],
  ['bp_20register_20masks',['BP Register Masks',['../group___b_p___register___masks.html',1,'']]]
];
