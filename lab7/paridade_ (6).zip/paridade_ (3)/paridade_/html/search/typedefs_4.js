var searchData=
[
  ['fgpio_5fmemmapptr',['FGPIO_MemMapPtr',['../group___f_g_p_i_o___peripheral.html#gaeed3beeb5e5c99ae5b0e404b21466e55',1,'MKL25Z4.h']]],
  ['ftfa_5fmemmapptr',['FTFA_MemMapPtr',['../group___f_t_f_a___peripheral.html#ga49d048bbeb55a090a5ecfe86ff767884',1,'MKL25Z4.h']]]
];
