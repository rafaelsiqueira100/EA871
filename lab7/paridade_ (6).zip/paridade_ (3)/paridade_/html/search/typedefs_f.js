var searchData=
[
  ['uart0_5fmemmapptr',['UART0_MemMapPtr',['../group___u_a_r_t0___peripheral.html#gae795171499e041fb9b8f6ad5b97f896b',1,'MKL25Z4.h']]],
  ['uart_5fmemmapptr',['UART_MemMapPtr',['../group___u_a_r_t___peripheral.html#ga306cf44b593fadbb29a065f42e3f68f0',1,'MKL25Z4.h']]],
  ['usb_5fmemmapptr',['USB_MemMapPtr',['../group___u_s_b___peripheral.html#gaabd989a49827dc34abb5de32732f4125',1,'MKL25Z4.h']]]
];
