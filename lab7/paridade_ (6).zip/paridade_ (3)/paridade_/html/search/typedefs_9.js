var searchData=
[
  ['nv_5fmemmapptr',['NV_MemMapPtr',['../group___n_v___peripheral.html#ga9aac431b01e6b976f2f4e32409ab725f',1,'MKL25Z4.h']]],
  ['nvic_5fmemmapptr',['NVIC_MemMapPtr',['../group___n_v_i_c___peripheral.html#ga685d87c766bb24fb3330aa8cc48fa0e7',1,'MKL25Z4.h']]]
];
