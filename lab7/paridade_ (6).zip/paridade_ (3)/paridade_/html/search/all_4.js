var searchData=
[
  ['endpt',['ENDPT',['../struct_u_s_b___mem_map.html#a86aaba02227a45a333f72565b0bec378',1,'USB_MemMap']]],
  ['entry',['ENTRY',['../struct_r_o_m___mem_map.html#ae744813808d96459e3920bade61dcc96',1,'ROM_MemMap']]],
  ['erren',['ERREN',['../struct_u_s_b___mem_map.html#a810f265a9ad6dc0f51834d0cecf24a79',1,'USB_MemMap']]],
  ['errstat',['ERRSTAT',['../struct_u_s_b___mem_map.html#ad86f18ee95df11168d4b6cf68578e0fa',1,'USB_MemMap']]],
  ['espera',['espera',['../util_8h.html#a16cc82fb968dcc6281cd3efc9bc2a982',1,'espera(uint32_t valor):&#160;util.c'],['../util_8c.html#a16cc82fb968dcc6281cd3efc9bc2a982',1,'espera(uint32_t valor):&#160;util.c']]],
  ['espera_5f5us',['espera_5us',['../util_8h.html#aeeb1d363914f33616415732d3b842cee',1,'espera_5us(uint32_t multiplos):&#160;util.c'],['../util_8c.html#aeeb1d363914f33616415732d3b842cee',1,'espera_5us(uint32_t multiplos):&#160;util.c']]]
];
