var searchData=
[
  ['off',['OFF',['../util_8h.html#a1dfd216318fb0a7374e158fd5e8f638caac132f2982b98bcaa3445e535a03ff75',1,'util.h']]],
  ['on',['ON',['../util_8h.html#a1dfd216318fb0a7374e158fd5e8f638ca977d478dacaae531f95695750d1e9d03',1,'util.h']]]
];
