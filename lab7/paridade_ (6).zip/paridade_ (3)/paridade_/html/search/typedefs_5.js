var searchData=
[
  ['gpio_5fmemmapptr',['GPIO_MemMapPtr',['../group___g_p_i_o___peripheral.html#ga31c1eddda45aa085f51142987e05ada5',1,'MKL25Z4.h']]]
];
