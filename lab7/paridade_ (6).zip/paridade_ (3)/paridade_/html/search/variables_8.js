var searchData=
[
  ['ldval',['LDVAL',['../struct_p_i_t___mem_map.html#ad664bbe0f8b53ee1e533727db4da3fb2',1,'PIT_MemMap']]],
  ['lockaccess',['LOCKACCESS',['../struct_m_t_b___mem_map.html#a6fea4948a50a4c0283e2fe15468ddb41',1,'MTB_MemMap']]],
  ['lockstat',['LOCKSTAT',['../struct_m_t_b___mem_map.html#aac267fb66879aa477f7e0185507d688b',1,'MTB_MemMap']]],
  ['lr',['LR',['../struct_r_t_c___mem_map.html#a6d1b4fe68ed53926b57392e7ad582469',1,'RTC_MemMap']]],
  ['ltmr64h',['LTMR64H',['../struct_p_i_t___mem_map.html#ad3448e6c2eea0b7ed2addf8ab1919bdf',1,'PIT_MemMap']]],
  ['ltmr64l',['LTMR64L',['../struct_p_i_t___mem_map.html#aa30a91d3094027918061fd20d9d0b845',1,'PIT_MemMap']]],
  ['lvdsc1',['LVDSC1',['../struct_p_m_c___mem_map.html#aeed619ce4a5bf17bff6201b02deebb54',1,'PMC_MemMap']]],
  ['lvdsc2',['LVDSC2',['../struct_p_m_c___mem_map.html#a934db8b39dae8b99a9a9165df50145f5',1,'PMC_MemMap']]]
];
