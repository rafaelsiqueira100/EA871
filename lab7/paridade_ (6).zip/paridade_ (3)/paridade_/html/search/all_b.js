var searchData=
[
  ['observe',['OBSERVE',['../struct_u_s_b___mem_map.html#a1bf837fd42e907a712c9f8e7261ea10d',1,'USB_MemMap']]],
  ['off',['OFF',['../util_8h.html#a1dfd216318fb0a7374e158fd5e8f638caac132f2982b98bcaa3445e535a03ff75',1,'util.h']]],
  ['ofs',['OFS',['../struct_a_d_c___mem_map.html#a89e51c569b4a0e4298bc4524afabb594',1,'ADC_MemMap']]],
  ['on',['ON',['../util_8h.html#a1dfd216318fb0a7374e158fd5e8f638ca977d478dacaae531f95695750d1e9d03',1,'util.h']]],
  ['osc0_5fbase_5fptr',['OSC0_BASE_PTR',['../group___o_s_c___peripheral.html#gaab1618c69a91b2e5d3385139b5b566f0',1,'MKL25Z4.h']]],
  ['osc_5fbase_5fptrs',['OSC_BASE_PTRS',['../group___o_s_c___peripheral.html#ga46f69fcb9d660e18b5cbf51adbbcec78',1,'MKL25Z4.h']]],
  ['osc_5fmemmap',['OSC_MemMap',['../struct_o_s_c___mem_map.html',1,'']]],
  ['osc_5fmemmapptr',['OSC_MemMapPtr',['../group___o_s_c___peripheral.html#gaaa685163f549fdf24c28ec9b400310b5',1,'MKL25Z4.h']]],
  ['osc',['OSC',['../group___o_s_c___peripheral.html',1,'']]],
  ['osc_20_2d_20register_20accessor_20macros',['OSC - Register accessor macros',['../group___o_s_c___register___accessor___macros.html',1,'']]],
  ['osc_20register_20masks',['OSC Register Masks',['../group___o_s_c___register___masks.html',1,'']]],
  ['otgctl',['OTGCTL',['../struct_u_s_b___mem_map.html#a615eaa9b0200d66323e8ee2650a49164',1,'USB_MemMap']]],
  ['otgicr',['OTGICR',['../struct_u_s_b___mem_map.html#a4cd829d73e01b3cf0a4fa9affedb210f',1,'USB_MemMap']]],
  ['otgistat',['OTGISTAT',['../struct_u_s_b___mem_map.html#a6eacb73f23f815f7686f4e7bf7eb2fcc',1,'USB_MemMap']]],
  ['otgstat',['OTGSTAT',['../struct_u_s_b___mem_map.html#a0398fe890efd8110f3d182e7fcb8a0c5',1,'USB_MemMap']]]
];
