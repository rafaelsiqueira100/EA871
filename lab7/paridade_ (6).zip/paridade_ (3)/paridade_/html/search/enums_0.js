var searchData=
[
  ['boolean_5ftag',['boolean_tag',['../util_8h.html#a1dfd216318fb0a7374e158fd5e8f638c',1,'util.h']]]
];
