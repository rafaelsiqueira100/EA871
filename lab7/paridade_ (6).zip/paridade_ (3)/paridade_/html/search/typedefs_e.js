var searchData=
[
  ['tpm_5fmemmapptr',['TPM_MemMapPtr',['../group___t_p_m___peripheral.html#ga32147338cedc9904efff0d19b3a358ac',1,'MKL25Z4.h']]],
  ['tsi_5fmemmapptr',['TSI_MemMapPtr',['../group___t_s_i___peripheral.html#gad1310fedc6b594554cdd760e371de570',1,'MKL25Z4.h']]]
];
