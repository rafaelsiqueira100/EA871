var searchData=
[
  ['osc',['OSC',['../group___o_s_c___peripheral.html',1,'']]],
  ['osc_20_2d_20register_20accessor_20macros',['OSC - Register accessor macros',['../group___o_s_c___register___accessor___macros.html',1,'']]],
  ['osc_20register_20masks',['OSC Register Masks',['../group___o_s_c___register___masks.html',1,'']]]
];
