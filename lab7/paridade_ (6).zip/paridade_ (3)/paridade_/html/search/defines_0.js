var searchData=
[
  ['mcu_5fmem_5fmap_5fversion',['MCU_MEM_MAP_VERSION',['../_m_k_l25_z4_8h.html#acb0f54172ffa1052aec8b964bf7642d6',1,'MKL25Z4.h']]],
  ['mcu_5fmem_5fmap_5fversion_5fminor',['MCU_MEM_MAP_VERSION_MINOR',['../_m_k_l25_z4_8h.html#a548743cf2764e560797b15c2a8b82e59',1,'MKL25Z4.h']]]
];
