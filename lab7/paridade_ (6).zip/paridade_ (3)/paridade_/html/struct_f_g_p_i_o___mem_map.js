var struct_f_g_p_i_o___mem_map =
[
    [ "PCOR", "struct_f_g_p_i_o___mem_map.html#a3b37c7b24e8edd80c1cbc5282a4a8a3c", null ],
    [ "PDDR", "struct_f_g_p_i_o___mem_map.html#add5e56027e27e8a0076bf1c38fdcaed5", null ],
    [ "PDIR", "struct_f_g_p_i_o___mem_map.html#af869762f9d42637f8fc09354e8947834", null ],
    [ "PDOR", "struct_f_g_p_i_o___mem_map.html#ab549d3ecd17467804bc780c97f83e034", null ],
    [ "PSOR", "struct_f_g_p_i_o___mem_map.html#a7179b85bd4a68dc196cb91b6433dd674", null ],
    [ "PTOR", "struct_f_g_p_i_o___mem_map.html#aa07e31d4362b7c29a10592d24511198c", null ]
];