var struct_p_o_r_t___mem_map =
[
    [ "GPCHR", "struct_p_o_r_t___mem_map.html#a84f8893cbefd6a3eff18b455f9069b29", null ],
    [ "GPCLR", "struct_p_o_r_t___mem_map.html#a837c289643f8cec958b1f01c086b558a", null ],
    [ "ISFR", "struct_p_o_r_t___mem_map.html#a53c86a08f430dc915a312efe74ba83e6", null ],
    [ "PCR", "struct_p_o_r_t___mem_map.html#a1c54a8f1741fade8daf28198fee43ddd", null ]
];