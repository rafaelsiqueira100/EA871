var group___t_s_i___peripheral =
[
    [ "TSI - Register accessor macros", "group___t_s_i___register___accessor___macros.html", null ],
    [ "TSI Register Masks", "group___t_s_i___register___masks.html", null ],
    [ "TSI_MemMap", "struct_t_s_i___mem_map.html", [
      [ "DATA", "struct_t_s_i___mem_map.html#af21190d34aa787d4660144470b71ad90", null ],
      [ "GENCS", "struct_t_s_i___mem_map.html#a14380d508e161af3b794962e7c3f8abb", null ],
      [ "TSHD", "struct_t_s_i___mem_map.html#aeede6a8023aabcd9c6fff71419ae4cce", null ]
    ] ],
    [ "TSI0_BASE_PTR", "group___t_s_i___peripheral.html#gaf98ea1cd15559446e0cfc1ae177751f6", null ],
    [ "TSI_BASE_PTRS", "group___t_s_i___peripheral.html#gaf0e643a8dc882d5a89dd6bb9a4ca3d16", null ],
    [ "TSI_MemMapPtr", "group___t_s_i___peripheral.html#gad1310fedc6b594554cdd760e371de570", null ]
];