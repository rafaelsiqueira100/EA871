var group___r_t_c___peripheral =
[
    [ "RTC - Register accessor macros", "group___r_t_c___register___accessor___macros.html", null ],
    [ "RTC Register Masks", "group___r_t_c___register___masks.html", null ],
    [ "RTC_MemMap", "struct_r_t_c___mem_map.html", [
      [ "CR", "struct_r_t_c___mem_map.html#a05c71be888cd40a4d91c631260d684d7", null ],
      [ "IER", "struct_r_t_c___mem_map.html#a1db69b589f5bfc5faa12b9c54e7c8061", null ],
      [ "LR", "struct_r_t_c___mem_map.html#a6d1b4fe68ed53926b57392e7ad582469", null ],
      [ "SR", "struct_r_t_c___mem_map.html#a82faed2f609de35e3b27d5fd27ba82e2", null ],
      [ "TAR", "struct_r_t_c___mem_map.html#a500ab794376810b97e2b2e01658f330c", null ],
      [ "TCR", "struct_r_t_c___mem_map.html#ab816b0540497796070202cd2f5bc10ed", null ],
      [ "TPR", "struct_r_t_c___mem_map.html#a32641b62d548255bdf2164b457a2aaeb", null ],
      [ "TSR", "struct_r_t_c___mem_map.html#a4ca4d2878d99736cbff0e8b107a275f2", null ]
    ] ],
    [ "RTC_BASE_PTR", "group___r_t_c___peripheral.html#ga6455e2b767b4b224b4f00b50e87a2441", null ],
    [ "RTC_BASE_PTRS", "group___r_t_c___peripheral.html#ga426dff8af34f3304d58b5bed5a54e583", null ],
    [ "RTC_MemMapPtr", "group___r_t_c___peripheral.html#gac92da66fe1171e5751505df29917b152", null ]
];