var group___f_g_p_i_o___peripheral =
[
    [ "FGPIO - Register accessor macros", "group___f_g_p_i_o___register___accessor___macros.html", null ],
    [ "FGPIO Register Masks", "group___f_g_p_i_o___register___masks.html", null ],
    [ "FGPIO_MemMap", "struct_f_g_p_i_o___mem_map.html", [
      [ "PCOR", "struct_f_g_p_i_o___mem_map.html#a3b37c7b24e8edd80c1cbc5282a4a8a3c", null ],
      [ "PDDR", "struct_f_g_p_i_o___mem_map.html#add5e56027e27e8a0076bf1c38fdcaed5", null ],
      [ "PDIR", "struct_f_g_p_i_o___mem_map.html#af869762f9d42637f8fc09354e8947834", null ],
      [ "PDOR", "struct_f_g_p_i_o___mem_map.html#ab549d3ecd17467804bc780c97f83e034", null ],
      [ "PSOR", "struct_f_g_p_i_o___mem_map.html#a7179b85bd4a68dc196cb91b6433dd674", null ],
      [ "PTOR", "struct_f_g_p_i_o___mem_map.html#aa07e31d4362b7c29a10592d24511198c", null ]
    ] ],
    [ "FGPIO_BASE_PTRS", "group___f_g_p_i_o___peripheral.html#ga58956e4d0a0ffec3e1dd70e77a5160b4", null ],
    [ "FPTA_BASE_PTR", "group___f_g_p_i_o___peripheral.html#ga4b0d89f517528ab7c1d2fdefe4c863d8", null ],
    [ "FPTB_BASE_PTR", "group___f_g_p_i_o___peripheral.html#ga725ec21a43213bffe0aa484f7406bcf5", null ],
    [ "FPTC_BASE_PTR", "group___f_g_p_i_o___peripheral.html#gaed3b8398ebed63795f9ce57eb9a59097", null ],
    [ "FPTD_BASE_PTR", "group___f_g_p_i_o___peripheral.html#gabaff6b055edb9ba703415d0473b92ca8", null ],
    [ "FPTE_BASE_PTR", "group___f_g_p_i_o___peripheral.html#ga191ce600c147c06111ecea5b3b0aa6fb", null ],
    [ "FGPIO_MemMapPtr", "group___f_g_p_i_o___peripheral.html#gaeed3beeb5e5c99ae5b0e404b21466e55", null ]
];