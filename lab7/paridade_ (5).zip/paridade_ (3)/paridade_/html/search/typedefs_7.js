var searchData=
[
  ['llwu_5fmemmapptr',['LLWU_MemMapPtr',['../group___l_l_w_u___peripheral.html#ga03cfefad45ecbfeb2cd16eb85ccfe186',1,'MKL25Z4.h']]],
  ['lptmr_5fmemmapptr',['LPTMR_MemMapPtr',['../group___l_p_t_m_r___peripheral.html#ga765226e2eeb35160c12820d4a2541320',1,'MKL25Z4.h']]]
];
