var searchData=
[
  ['i2c_5fmemmapptr',['I2C_MemMapPtr',['../group___i2_c___peripheral.html#ga9902bc02a12982d0c37ec011b4dd89f0',1,'MKL25Z4.h']]]
];
