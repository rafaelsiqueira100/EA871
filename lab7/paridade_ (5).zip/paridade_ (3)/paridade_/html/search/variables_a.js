var searchData=
[
  ['observe',['OBSERVE',['../struct_u_s_b___mem_map.html#a1bf837fd42e907a712c9f8e7261ea10d',1,'USB_MemMap']]],
  ['ofs',['OFS',['../struct_a_d_c___mem_map.html#a89e51c569b4a0e4298bc4524afabb594',1,'ADC_MemMap']]],
  ['otgctl',['OTGCTL',['../struct_u_s_b___mem_map.html#a615eaa9b0200d66323e8ee2650a49164',1,'USB_MemMap']]],
  ['otgicr',['OTGICR',['../struct_u_s_b___mem_map.html#a4cd829d73e01b3cf0a4fa9affedb210f',1,'USB_MemMap']]],
  ['otgistat',['OTGISTAT',['../struct_u_s_b___mem_map.html#a6eacb73f23f815f7686f4e7bf7eb2fcc',1,'USB_MemMap']]],
  ['otgstat',['OTGSTAT',['../struct_u_s_b___mem_map.html#a0398fe890efd8110f3d182e7fcb8a0c5',1,'USB_MemMap']]]
];
