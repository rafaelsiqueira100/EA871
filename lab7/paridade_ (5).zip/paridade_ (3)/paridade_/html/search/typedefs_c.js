var searchData=
[
  ['rcm_5fmemmapptr',['RCM_MemMapPtr',['../group___r_c_m___peripheral.html#ga787b1c58d947f0b81c2502227dd0396b',1,'MKL25Z4.h']]],
  ['rom_5fmemmapptr',['ROM_MemMapPtr',['../group___r_o_m___peripheral.html#ga443285c54b394d010d2dccd28607e4b4',1,'MKL25Z4.h']]],
  ['rtc_5fmemmapptr',['RTC_MemMapPtr',['../group___r_t_c___peripheral.html#gac92da66fe1171e5751505df29917b152',1,'MKL25Z4.h']]]
];
