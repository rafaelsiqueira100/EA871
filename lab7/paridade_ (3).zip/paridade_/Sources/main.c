/*
 * main implementation: use this 'C' sample to create your own application
 *
 */
/**
 * @file main.c
 * @brief Este projeto demonstra o uso de um buffer circular para compatibilizar
 * a velocidade de dois dispositivos. Ao digitar uma das seguintes palavras em maiusculas 		
 * VERDE, VINHO, VIOLETA, VERMELHO, VIRIDIANO, s�o "ecoadas" a palavra digitada 10x no Terminal 
 * @author Beatriz Moura e Rafael Andre
 * @date 04/05/2023
 *
 */
#include "stdlib.h"
#include "string.h"
#include "UART.h"
#include "ISR.h"
#include "SIM.h"
#include "buffer_circular.h"
#include "util.h"
#include "derivative.h" /* include peripheral declarations */
uint8_t ExtraiString2Tokens (char *str,uint8_t *i, char **tokens){
	char delim[] = " "; //Delimitador
	char *aux[3]; 
	
	//Extracao do primeiro token
	aux[0]=strtok(str, delim); //Op
	
	if(*aux[0]!='I' && *aux[0]!='i' && *aux[0]!='p' && *aux[0]!='P'){
		return 3; //Operacao invalida
	}
	*i+=1;
	aux[1]=strtok(NULL, delim); //Valor
	*i+=1;
	while(strtok(NULL,delim) != '\0'){
		*i+=1; 
	}
	if(*i != 2){
			return 1; //Quantidade incorreta de tokens
		}
	tokens[0]=aux[0];
	tokens[1]=aux[1];
	tokens[3]='\0';
	return 0;
}

int main(void)
{		
	uint8_t i; 
	char *tokens[3];
	char str;
	char *bin=NULL; 
	SIM_setaFLLPLL (0);              //seta FLL
	/*
	* Configurar sinais de relogio e pinos
	*/
	UART0_config_basica(0b1);
	/*
	* Configura o modulo UART0
	*/
	//MCGFLLCLK em 20,971520MHz
	UART0_config_especifica(20971520, 38400, 0x0B, 2);
	
	//Habilitar a interrupcao do canal Rx 
	UART0_habilitaInterruptRxTerminal();
	//enable_irq(12); set_irq_priority(12, 3);
	UART0_habilitaNVICIRQ12(0b11);
	
	ISR_inicializaBC();
	

	ISR_EnviaString ("Digite um numero em base binaria, decimal ou hexadecimal:\n\r");
	ISR_escreveEstado(EXPRESSAO);

	
	for(;;) {	   
	
	}
	
	return 0;
}
