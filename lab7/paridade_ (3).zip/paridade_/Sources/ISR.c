/*
 * ISR.c
 *
 */
#include "derivative.h"
#include "buffer_circular.h"
#include "ISR.h"

#define TAM_MAX 13
static uint8_t flag;
static BufferCirc_type bufferE;				//buffer de entrada
static BufferCirc_type bufferS;	//buffer de saida Terminal 

void UART0_IRQHandler (void)
{
	char item;
	uint32_t valor;
	uint8_t sign;
	char first_c = ' '; //Primeiro caractere do segundo token
		if (UART0_S1 & UART0_S1_RDRF_MASK) {
			item= UART0_D; //Interrupcao solicitada pelo RX 
			switch(flag)
			case EXPRESSAO:
				ISR_extraiString(&str);
				ISR_escreveEstado(TOKENS);
				break;
			case TOKENS:
				sign = ExtraiString2Tokens(&str, &i, tokens);
				first_c = *(*tokens+1);
				if(sign != 0){
					//Mensagem erro 3
					//Mensagem erro 1
					ISR_escreveEstado(ERRO);
					break;
				}
				else{
					
					ISR_escreveEstado(COMPUTO);
					break;
				}
				size_t str_len = strlen(str); 
				if(str==NULL || str_len >8 || str_len > 32){ //O valor convertido pode ser maior do que 2^(32-1)
					//Mensagem de erro 2
					ISR_escreveEstado(ERRO);
					break;
				}
				
			case COMPUTO:
				/*
				 * Conversao da string para inteiro 
				 */
				if(first_c=='b' || first_c == 'B'){ //Conversao binaria
					ConvertBitStringtoUl32(&str,&valor);
				}
				else if(first_c == 'h' || first_c == 'H')){ //Conversao hexadecimal
					ConvertHexStringtoUl32(&str, &valor);  
				}
				else if(first_c >='0' && first_c <= '9'){ //Conversao decimal
					ConvertDecStringtoUl32(&str, &valor); 
				}
				else{
					//Mensagem de erro de entrada invalida
					ISR_escreveEstado(ERRO);
					break;
				}
				bin = ConvertUl32toBitString(valor,bin);
				ISR_EnviaString(bin);	
				uint8_t parity = findParity(valor);
			case RESULTADO: 
			case ERRO: 
				ISR_EnviaString ("Erro de tokens. Digite um numero valido: \n\r");
				ISR_escreveEstado(EXPRESSAO);
			
			UART0_D = item; //ecoar o caractere
			if (item == '\r') {
				BC_push (&bufferE, '\0');
				while (!(UART0_S1 & UART_S1_TDRE_MASK));
				UART0_D = '\n';
			} 
			else {
				BC_push (&bufferE, item);
			}
		} else if (UART0_S1 & UART0_S1_TDRE_MASK) {
			if (BC_isEmpty(&bufferS))
				UART0_C2 &= ~UART0_C2_TIE_MASK;
			else {
				BC_pop (&bufferS, &item);
				UART0_D = item;
			}
		}
}

void ISR_inicializaBC () {
	/*!
	 * Inicializa um buffer circular de entrada
	 */
	BC_init (&bufferE, TAM_MAX);

	/*!
	 * Inicializa o buffer circular de saida
	 */
	BC_init(&bufferS, TAM_MAX);
}

void ISR_EnviaString (char *string) {
	uint8_t i;
	
	while (BC_push( &bufferS, string[0])==-1);
	UART0_C2 |= UART0_C2_TIE_MASK;
	i=1;
	while (string[i] != '\0') {
		while (BC_push( &bufferS, string[i])==-1);
		i++;
	}
}

void ISR_extraiString (char *string) {
	//Entrada de uma nova string
	uint8_t i=0;
	BC_pop (&bufferE, &string[i]);
	while (string[i] != '\0') {
		BC_pop (&bufferE, &string[++i]);				
	}
}
