/*
 * @file buffer_circular.h
 * @brief Arquivo-cabecalho de buffer_circular.c
 * @author Wu Shin-Ting
 * @date 21/06/2021
 */
#include "stdint.h"

#ifndef BUFFER_CIRCULAR_H_
#define BUFFER_CIRCULAR_H_

//=====================================
// Estrutura de dados: buffer circular
//=====================================
typedef struct BufferCirc_tag
{
	char * dados;  	 // buffer de dados
	unsigned int tamanho;	// quantidade total de elementos
	unsigned int leitura;       // indice de leitura (tail)  
	unsigned int escrita;       // indice de escrita (head)
} BufferCirc_type;
/*!
 * @brief Inicializa um buffer circular com tamanho especificado
 * @param[in] *buffer
 * @param[in] tamanho
 */
void BC_init(BufferCirc_type *buffer, unsigned int tamanho);

/*!
 * @brief Reseta um buffer circular com tamanho igual a 1
 * @param[in] *buffer
 */
void BC_reset(BufferCirc_type *buffer);

/*!
 * @brief Libera o espa�o de mem�ria ocupado pelos dados num buffer circular 
 * @param[in] *buffer
 */
void BC_free(BufferCirc_type *buffer);
/*!
 * @brief Adiciona um novo elemento num buffer circular 
 * @param[in] *buffer
 * @param[in] item
 */
int BC_push (BufferCirc_type *buffer, char item);

/*!
 * @brief Remove um elemento num buffer circular 
 * @param[in] *buffer
 * @param[in] *item
 */
int BC_pop (BufferCirc_type *buffer, char *item);

/*!
 * @brief Conta a quantidade de elementos num buffer circular 
 * @param[in] *buffer
 */
unsigned int BC_elements (BufferCirc_type *buffer);

/*!
 * @brief Verifica se o buffer esta cheio e retorna uma flag 
 * @param[in] *buffer
 * @param[out] i 
 */
uint8_t BC_isFull (BufferCirc_type *buffer);

/*!
 * @brief Verifica se o buffer esta vazio e retorna uma flag 
 * @param[in] *buffer
 * @param[out] i 
 */
uint8_t BC_isEmpty (BufferCirc_type *buffer);

#endif /* BUFFER_CIRCULAR_H_ */
