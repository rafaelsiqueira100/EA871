/*
 * @file main.h
 * @brief Este projeto demonstra o uso do modulo UART e buffer circular
 *  Created on: Jan 24, 2023
 *      Author: Ting
 */

#ifndef MAIN_H_
#define MAIN_H_



#endif /* MAIN_H_ */
