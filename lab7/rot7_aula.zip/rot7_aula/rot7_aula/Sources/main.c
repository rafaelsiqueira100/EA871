/**
 * @file main.c
 * @brief Este projeto demonstra o uso de um buffer circular para compatibilizar
 * a velocidade de dois dispositivos. Ao digitar uma das seguintes palavras em maiusculas 		
 * VERDE, VINHO, VIOLETA, VERMELHO, VIRIDIANO, s�o "ecoadas" a palavra digitada 10x no Terminal 
 * @author Wu Shin-Ting
 * @date 05/03/2022
 *
 */
#include "stdlib.h"
#include "string.h"

#include "UART.h"
#include "ISR.h"
#include "SIM.h"
#include "buffer_circular.h"

/*!
 * @brief Variavel de configuracao de UART0
 */
UART0Config_type config0 = {
//		.bdh_sbns=0,		///< Um stop bit
		.bdh_sbns=1,		///< Dois stop bits
		.sbr=0b100, 		///< MCGFLLCLK/(baud_rate*osr)=4
		.c1_loops=0,		///< Operacao normal: full-duplex 
		.c1_dozeen=0,		///< UART habilitado no modo WAIT
		.c1_rsrc=0,			///< nao tem efeito para loops == 0
		.c1_m=0,			///< dados em 8 bits
		.c1_wake=0,			///< wakeup de RX por linha ociosa (IDLE)
		.c1_ilt=0,			///< deteccao do estado ocioso pela contagem apos start bits
		.c1_pe=0,			///< sem checagem de paridade por hardware
		.c1_pt=0,			///< bit de paridade par (sem efeito se pe==0)
		.c2_rwu=0,			///< operacao normal de recepcao do UART0
		.c2_sbk=0,			///< operacao normal de transmissor do UART0
		.s2_msbf=0,			///< envio de MSB para LSB
		.s2_rxinv=0,		///< polaridade dos dados de RX nao eh invertida
		.s2_rwuid=0,		///< nao tem efeito para rwu==0
		.s2_brk13=0,		///< nao tem efeito para operacao normal de transmissor
		.s2_lbkde=0,		///< deteccao do caractere break no tamanho menor
		.c3_r8t9=0,			///< nao tem efeito para m==0
		.c3_r9t8=0,			///< nao tem efeito para m==0
		.c3_txdir=0,		///< nao tem efeito para loops==0
		.c3_txinv=0,		///< polaridade dos dados de TX nao eh invertida 
		.c4_maen1=0,		///< todos os dados recebidos sao transferidos para buffer de dados
		.c4_maen2=0,			
		.c4_m10=0,			///< tamanho dos dados em RX e TX � 8 ou 9 bits
		.c4_osr=0b01111,	///< superamostragem 16x
		.c5_tdmae=0,		///< uso de DMA pelo TX desabilitada
		.c5_rdmae=0,		///< uso de DMA pelo RX desabilitado
		.c5_bothedge=0,		///< amostragem somente na borda de subida do clock
		.c5_resyncdis=0		///< resincronizacao na recepcao habilitada
};

/*!
 * @brief Variavel de configuracao de UART2
 */
UARTConfig_type config2 = {
//		.bdh_sbns=0,		///< Um stop bit
		.bdh_sbns=1,		///< Dois stop bits
		.sbr=0b100, 		///< MCGFLLCLK/(baud_rate*osr)=4
		.c1_loops=0,		///< Operacao normal: full-duplex 
		.c1_uartswai=0,		///< clock de UART continua correndo no modo WAIT
		.c1_rsrc=0,			///< nao tem efeito para loops == 0
		.c1_m=0,			///< dados em 8 bits
		.c1_wake=0,			///< wakeup de RX por linha ociosa (IDLE)
		.c1_ilt=0,			///< deteccao do estado ocioso pela contagem apos start bits
		.c1_pe=0,			///< sem checagem de paridade por hardware
		.c1_pt=0,			///< bit de paridade par (sem efeito se pe==0)
		.c2_rwu=0,			///< operacao normal de recepcao do UART0
		.c2_sbk=0,			///< operacao normal de transmissor do UART0
		.s2_rxinv=0,		///< polaridade dos dados de RX nao eh invertida
		.s2_rwuid=0,		///< nao tem efeito para rwu==0
		.s2_brk13=0,		///< nao tem efeito para operacao normal de transmissor
		.s2_lbkde=0,		///< deteccao do caractere break no tamanho menor
		.c3_r8=0,			///< precisa ser lido para completar o MSB dos dados quando m == 1
		.c3_t8=0,			///< precisa ser setado com o MSB dos dados quando m == 1
		.c3_txdir=0,		///< nao tem efeito para loops==0
		.c3_txinv=0,		///< polaridade dos dados de TX nao eh invertida 
		.c4_tdmas=0,		///< selecionar transmissor para transferencia DMA
		.c4_rdmas=0 		///< selecionar receptor para transferencia DMA
};

// Baud rates: 300, 1200, 2400, 4800, 9600, 19200, 38400, 57600, 115200
#define BAUD_RATE 38400
//#define BAUD_RATE 38400

/*!
 * @brief Ecoa em linhas de 10 palavras o nome da cor digitado em ma�uscula
 */
int main (void)
{	
	/*
	 * Frequencia de configuracao padrao do fabricante: MCGFLLCLK = 20971520Hz
	 * Bus Clock na frequencia 20971520Hz
	 */
	SIM_setaOUTDIV4 (0b000);
	
	/*
	 * Configurar UART0 com Rx e Tx habilitados: SBR tem que ser aproximado para maior que baud rate setado
	 */
	config0.sbr = (uint16_t)(20971520./(BAUD_RATE * (config0.c4_osr+1)));
	if ((20971520./(1.0 * BAUD_RATE * (config0.c4_osr+1))) > config0.sbr)
		config0.sbr++;
	UART0_initTerminal (&config0);

	/*!
	 * Configurar UART2 com Tx habilitado: SBR tem que ser aproximado para meior que baud rate setado
	 */
	config2.sbr = (uint16_t)(20971520./(BAUD_RATE * 16));
	if ((20971520./(1.0 * BAUD_RATE * 16)) > config2.sbr)
		config2.sbr++;
	UART_initH5Pin2(&config2);

	/*!
	 * Habilita IRQs
	 */
	UART0_habilitaIRQTerminal (0);
	UART_habilitaIRQH5Pin2 (1);

	// Setup
	ISR_inicializaBC();
	
	/*!
	 * Habilita a interrupcao do Rx do UART0
	 */
	UART0_habilitaInterruptRxTerminal();

	char string[16];
	
	/*!
	 * Reseta o estado do aplicativo
	 */
	ISR_EnviaString ("Digite [VERDE|VINHO|VIOLETA|VERMELHO|VIRIDIANO]:\n\r");
	ISR_escreveEstado (ESPERA);
	string[0] = '\0';
	
	for(;;) {
		if (ISR_LeEstado() == EXTRAI) {
			ISR_extraiString (string);
			ISR_escreveEstado (MOSTRA);
		}
		if (ISR_LeEstado() == MOSTRA) {
			if (strcmp (string, "VERDE") == 0) {
				ISR_EnviaString10x ("Verde");
				ISR_Realinhamento();
			} else if (strcmp (string, "VINHO") == 0) {
				ISR_EnviaString10x ("Vinho");
				ISR_Realinhamento();
			} else if (strcmp (string, "VIOLETA") == 0) {
				ISR_EnviaString10x ("Violeta");
				ISR_Realinhamento();
			} else if (strcmp (string, "VERMELHO") == 0) {
				ISR_EnviaString10x ("Vermelho");
				ISR_Realinhamento();
			} else if (strcmp (string, "VIRIDIANO") == 0) {
				ISR_EnviaString10x ("Viridiano");
				ISR_Realinhamento();
			} 
			else {
				ISR_EnviaString ("Digite novamente\n\r");
				ISR_escreveEstado (ESPERA); //reseta estado 
			}
		} else if (ISR_LeEstado() == LIBERA_BUFFER) {
			//Aguardar o envio completo dos caracteres
			while (!ISR_BufferSaidaVazio());
			ISR_EnviaString ("Digite [VERDE|VINHO|VIOLETA|VERMELHO|VIRIDIANO]:\n\r");
			ISR_escreveEstado (ESPERA); 	//reseta estado 
		}
	}	
	return 0;
}
